<?php
class db_manager extends AWS_ADMIN_CONTROLLER
{
    public function setup()
    {
        TPL::assign('menu_list',$this->fetch_menu_list());
    }

    public function index_action()
    {
        $list = AWS_APP::model()->query_all("SHOW TABLE STATUS");
        TPL::assign('setting',get_setting());
        TPL::assign('list',$list);
        TPL::output('admin/db_manager/index');
    }

    public function manager_action()
    {
        define('IN_AJAX',true);
        $action = $_POST['action'];
        $name_arr = $_POST['names'];
        if(!$action || !$name_arr)
        {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index/')), -1, '请选择您要操作的数据表'));
        }
        switch ($action)
        {
            case 'backup':
                $this->backup($name_arr);
                break;
            case 'repair':
                $this->repair_all($name_arr);
                break;
            case 'optimize':
                $this->optimize_all($name_arr);
                break;
            case 'remove':
                if(is_array($name_arr))
                {
                    foreach ($name_arr as $name)
                    {
                        unlink(ROOT_PATH.get_setting('db_back_path').$name);
                    }
                }else{
                    unlink(ROOT_PATH.get_setting('db_back_path').$name_arr);
                }
                H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/backup_list/')), 1, '备份数据删除成功'));
                break;
        }
    }

    /**
     * SQL查询
     */
    public function query_action()
    {
        $do_action = $_POST['do_action'];
        $table_name = $_POST['table_name'];

        if (in_array($do_action, array('do_query', 'optimize_all', 'repair_all'))) {
            $this->$do_action();
        } elseif (count($table_name) == 0) {
            exit();
        } else {
            foreach ($table_name as $table) {
                $this->$do_action($table);
                echo "<br />";
            }
        }
    }

    /*备份列表*/
    public function backup_list_action()
    {
        $backupDir =  ROOT_PATH.get_setting('db_back_path');
        $backupList = [];
        $extend = '*.sql*';
        foreach (glob($backupDir .  $extend) as $filename)
        {
            $time = filemtime($filename);
            $backupList[$time] = [
                'file' => str_replace($backupDir, '', $filename),
                'date' => date("Y-m-d H:i:s", $time),
                'size' => filesize($filename)/1024
            ];
        }
        krsort($backupList);
        TPL::assign('list',$backupList);
        TPL::output('admin/db_manager/backup_list');
    }

    /*还原*/
    public function restore_action()
    {
        $name = $_GET['name'];
        $path = ROOT_PATH.get_setting('db_back_path'). $name;
        $files = glob($path);
        $list = array();
        foreach ($files as $name) {
            $basename = basename($name);
            $match = sscanf($basename, '%4s%2s%2s-%2s%2s%2s-%d');
            $gz = preg_match('/^\d{8,8}-\d{6,6}-\d+\.sql.gz$/', $basename);
            $list[$match[6]] = array($match[6], $name, $gz);
        }
        ksort($list);
        // 检测文件正确性
        $last = end($list);
        if (count($list) === $last[0]) {
            foreach ($list as $item) {
                $config = [
                    'path' => ROOT_PATH.get_setting('db_back_path'),
                    'compress' => $item[2]
                ];
                $this->model('dbManager')->init($item, $config);
                $start = $this->model('dbManager')->import(0);
                // 导入所有数据
                while (0 !== $start) {
                    if (false === $start) {
                        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/backup_list/')), -1, '还原失败'));
                    }
                    $start = $this->model('dbManager')->import($start[0]);
                }
            }
        }
        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/backup_list/')), 1, '还原成功'));
    }

    /*备份*/
    public function backup($tables)
    {
        //读取备份配置
        $config = array(
            'path'     => ROOT_PATH.get_setting('db_back_path'),
            'part'     => intval(get_setting('db_back_part_size')) * 1024*1024,
            'compress' => get_setting('db_back_compress'),
            'level'    => get_setting('db_back_compress_level')
        );
        //检查是否有正在执行的任务
        $lock = "{$config['path']}backup.lock";
        if(is_file($lock))
        {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index/')), -1, '检测到有一个备份任务正在执行，请稍后再试'));
        } else {
            if (!is_dir($config['path'])) {
                $this->create_file($config['path'], 0755);
            }
            //创建锁文件
            file_put_contents($lock, time());
        }
        //生成备份文件信息
        $file = [
            'name' => date('Ymd-His', time()),
            'part' => 1,
        ];
        // 创建备份文件
        $this->model('dbManager')->init($file, $config);
        if($this->model('dbManager')->create() !== false) {
            // 备份指定表
            foreach ($tables as $table) {
                $start = $this->model('dbManager')->backup($table, intval($start));
                while (0 !== $start) {
                    if (false === $start) {
                        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index/')), -1, '备份出错啦'));
                    }
                    $start = $this->model('dbManager')->backup($table, $start[0]);
                }
            }
            // 备份完成，删除锁定文件
            unlink($lock);
        }
        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/backup_list')), 1, '备份成功'));
    }

    /*查看表结构*/
    public function view_info_action($name)
    {
        $row = AWS_APP::model()->query_all("SHOW CREATE TABLE `{$name}`");
        $row = array_values($row[0]);
        $info = $row[1];
        echo "<xmp>{$info};</xmp>";
    }

    /*查看表数据*/
    public function view_data_action($name = '')
    {
        $sql_query = "SELECT * FROM `{$name}`";
        $this->do_query($sql_query);
    }

    /*优化单张表*/
    public function optimize_action()
    {
        $name = $_GET['name'];
        if (AWS_APP::model()->query_all("OPTIMIZE TABLE `{$name}`")) {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, '优化表 '.$name.' 成功'));
        } else {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, '优化表 '.$name.' 失败'));
        }
    }

    /*优化多张表*/
    public function optimize_all($names = [])
    {
        $str = '';
        foreach ($names as $name) {
            if (AWS_APP::model()->query_all("OPTIMIZE TABLE `{$name}`")) {
                $str.= '优化表'.$name.'成功';
            } else {
                $str.= '优化表'.$name.'失败';
            }
            $str.= "<br />";
        }
        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, $str));
    }

    /*修复单张表*/
    public function repair_action()
    {
        $name = $_GET['name'];
        if (AWS_APP::model()->query_all("REPAIR TABLE `{$name}`")) {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, '修复表 '.$name.' 成功'));
        } else {
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), 1, '修复表 '.$name.' 成功'));
        }
    }

    /*修复多张表*/
    public function repair_all($names=[])
    {
        $str = '';
        foreach ($names as $key => $name) {
            if (AWS_APP::model()->query_all("REPAIR TABLE `{$name}`")) {
                $str.= '修复表'.$name.'成功';
            } else {
                $str.= '修复表'.$name.'失败';
            }
            $str.= "<br>";
        }
        H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, $str));
    }

    /*执行sql查询*/
    public function do_query($sql_query)
    {
        $sql_query = str_replace("\r", "", $sql_query);
        $sqls = preg_split("/;[ \t]{0,}\n/i", $sql_query);
        $max_return = 100;
        $r = '';
        foreach ($sqls as $key => $val) {
            if (trim($val) == '') {
                continue;
            }
            $val = rtrim($val, ';');
            $r .= "SQL：<span style='color:green;'>{$val}</span> ";
            if (preg_match("/^(select|explain)(.*)/i ", $val)) {
                $star_time = time();
                $limit = stripos(strtolower($val), "limit") !== false ? true : false;
                $count = AWS_APP::model()->query_all($val);
                if ($count > 0) {
                    $result_list = AWS_APP::model()->query_all($val . (!$limit && $count > $max_return ? ' LIMIT ' . $max_return : ''));
                } else {
                    $result_list = [];
                }
                $end_time = time();
                $time = $end_time-$star_time;
                $used_seconds = _e('查询消耗 %s 秒', $time) . "<br />";
                if ($count <= 0) {
                    $r .= '查询结果为空';
                } else {
                    $r .= (_e('总共:%s', $count) . (!$limit && $count > $max_return ? ',' . _e('最大返回:%s', $max_return) : ""));
                }
                $r = $r . ',' . $used_seconds;
                $j = 0;
                foreach ($result_list as $m => $n) {
                    $j++;
                    if (!$limit && $j > $max_return) {
                        break;
                    }
                    $r .= "<hr/>";
                    $r .= "<font color='red'>" . _e('数据量:%s', $j) . "</font><br />";
                    foreach ($n as $k => $v) {
                        $r .= "<font color='blue'>{$k}：</font>{$v}<br/>\r\n";
                    }
                }
            } else {
                $star_time = time();
                $count = AWS_APP::model()->query_all($val);
                $end_time = time();
                $time = $end_time-$star_time;
                $r .= '查询影响'. $count.'行数据总共耗时'.$time.'秒';
            }
        }
        echo $r;
    }

    /*检查文件权限*/
    private function create_file($path, $mode = 0755)
    {
        if (is_dir($path)) {
            return true;
        }
        $path = str_replace("\\", "/", $path);
        if (substr($path, -1) != '/') {
            $path = $path.'/';
        }
        $temp = explode('/', $path);
        $cur_dir = '';
        $max = count($temp) - 1;
        for ($i=0; $i<$max; $i++) {
            $cur_dir .= $temp[$i].'/';
            if (@is_dir($cur_dir)) {
                continue;
            }
            @mkdir($cur_dir, $mode, true);
            @chmod($cur_dir, $mode);
        }
        return is_dir($path);
    }

    public function remove_lock_file_action()
    {
        if(is_file(get_setting('db_back_path')."backup.lock"))
        {
            unlink(get_setting('db_back_path')."backup.lock");
            H::ajax_json_output(AWS_APP::RSM(array('url'=>get_js_url('/admin/db_manager/index')), -1, '删除成功'));
        }
    }
}