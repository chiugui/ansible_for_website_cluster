INSERT IGNORE INTO `[#DB_PREFIX#]system_setting
` (`varname`, `value`) VALUES ('wecenter_website',  's:1:"N";');