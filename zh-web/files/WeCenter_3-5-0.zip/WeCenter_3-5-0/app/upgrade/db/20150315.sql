INSERT IGNORE INTO `[#DB_PREFIX#]system_setting` (`varname`, `value`) VALUES ('ucenter_path', 's:0:"";');
