<?php
/*
+--------------------------------------------------------------------------
|   WeCenter [#RELEASE_VERSION#]
|   ========================================
|   by WeCenter Software
|   © 2011 - 2014 WeCenter. All Rights Reserved
|   http://www.wecenter.com
|   ========================================
|   Support: WeCenter@qq.com
|
+---------------------------------------------------------------------------
*/


if (!defined('IN_ANWSION'))
{
	die;
}
 
class pay_unipay_class extends AWS_MODEL
{
	public function __construct()
	{
		spl_autoload_register(function ($class) {
		    if (stripos($class, 'Pay\\') === 0) {
		        list($search, $replace) = [['\\', 'Pay/'], ['/', 'src/']];
		        $filename = __DIR__ . DIRECTORY_SEPARATOR . str_replace($search, $replace, $class) . '.php';
		        file_exists($filename) && include $filename;
		    }
		});

		$this->config = require(__DIR__ . '/config.php');	
		require(__DIR__ . '/src/Qrcode/phpqrcode.php');
		require_once __DIR__ . '/log.php';

		//初始化日志
		$logHandler= new CLogFileHandler(__DIR__ . "/logs/".date('Y-m-d').'.log');
		$log = Log::Init($logHandler, 15);
	}

	//支付宝支付
	public function alipay($data)
	{
		$options = array(
		    'out_trade_no' => $data['out_trade_no'], 
		    'total_amount' => $data['money'], 
		    'subject'      => $data['remarks'], 
		);

		$this->config['alipay']['notify_url']=$data['notify_url'];
		$pay = new \Pay\Pay($this->config);

        try {
			$result = $pay->driver('alipay')->gateway($data['gateway'])->apply($options);
            if($data['gateway']=='scan')
            {
                $name='/uploads/pay/'.$data['out_trade_no'].'.jpg';
                $filename ='.'.$name;
                $this->qr_code($result['qr_code'],$filename);
                return $name;
            }
            return $result;
        } 
        catch (Exception $e) 
        {
            return $e->getMessage();
        }
	}

	//微信支付
	public function wxpay($data)
	{
		$options = array(
		    'out_trade_no'     => $data['out_trade_no'], 
		    'total_fee'        => $data['money'], 
		    'body'             => $data['remarks'],
		    'spbill_create_ip' => '127.0.0.1', 
		);

		$this->config['wechat']['notify_url']=$data['notify_url'];
		$pay = new \Pay\Pay($this->config);

        try {
            $result = $pay->driver('wechat')->gateway($data['gateway'])->apply($options);
            if($data['gateway']=='scan')
            {
                $name='/uploads/pay/'.$data['out_trade_no'].'.jpg';
                $filename ='.'.$name;
                $this->qr_code($result,$filename);
                return $name;
            }
            return $result;
        } 
        catch (Exception $e) 
        {
            return $e->getMessage();
        }
	}

	//余额支付
	public function yepay($data)
	{
		$order['pay_time'] = time();
		$order['pay_status'] = 1;
		$order['out_trade_no'] = $data['out_trade_no'];
		$order['money'] = $data['money'];
		$order['subject'] = $data['remarks'];
		$order['trade_status'] = 'OK';

		HTTP::request($data['notify_url'],'POST',$order);
	}

    public function qr_code($url,$filename)
    {
        QRcode::png($url,$filename);
    }

    public function dopay($data)
    {
        switch ($data['driver']) 
		{
			case 'alipay':
				return $this->alipay($data);
				break;
			case 'wechat':
				return $this->wxpay($data);
				break;
			case 'yepay':
				return $this->yepay($data);
				break;			
			default:
				# code...
				break;
		}
    }

	public function get_order($uid,$offset)
	{
		$data = $this->model('account')->fetch_all('recharge','uid='.$uid,'addtime desc',10,$offset);
		foreach ($data as $key => $va) {
			switch ($va['pay_type']) 
			{
				case '1':
					$data[$key]['title'] = '悬赏';
					break;
				case '2':
					$data[$key]['title'] = '问题的回答打赏';
					break;
				case '3':
					$data[$key]['title'] = '文章打赏';
					break;
				case '3':
					$data[$key]['title'] = '咨询';
					break;			
				default:
					# code...
					break;
			}
			
		}
		return $data;
	}

	public function get_detail_order($id)
	{
		$detail = $this->model('account')->fetch_row('order_detail',"`id`=".$id."" );
		switch ($detail['relation_type']) 
		{
			case 1:
				$consume_detail=$this->model('account')->fetch_row('consume_detail',"`id`=".$detail['relation_id']."" );
				$item=$this->model('account')->fetch_row('consult',"`id`=".$consume_detail['relation_id']."" );;
				$detail['item']['title']='<a style="color:#000;" target="__blank" href="/consult/'.$item['question_id'].'">'.$item['question_content'].'</a>';
				$detail['item']['id']=$item['id'];
				break;
			case 2:
				$reward_detail=$this->model('account')->fetch_row('user_reward',"`id`=".$detail['relation_id']."" );
				if($reward_detail['cate']==2){
					$item=$this->model('account')->fetch_row('article',"`id`=".$reward_detail['both_id']."" );
					$detail['item']['title']='<a style="color:#000;" target="__blank" href="/article/'.$item['id'].'">'.$item['question_content'].'</a>';
					$detail['item']['id']=$item['id'];
				}else{
					$question_id=$this->model('account')->fetch_one('answer','question_id',"`answer_id`=".$reward_detail['both_id']."" );
					$item=$this->model('account')->fetch_row('question',"`question_id`=".$question_id."" );
					$detail['item']['title']='<a style="color:#000;" target="__blank" href="/question/'.$item['question_id'].'">'.$item['question_content'].'</a>';
				}
			case 5:
				$finance_detail=$this->model('account')->fetch_row('user_finance',"`id`=".$detail['relation_id']."" );
				$item=$this->model('account')->fetch_row('question',"`question_id`=".$finance_detail['question_id']."" );
				$detail['item']['title']='<a style="color:#000;" target="__blank" href="/question/'.$item['question_id'].'">'.$item['question_content'].'</a>';
				break;			
			default:
				# code...
				break;
		}
		return $detail;
	}

	public function get_all_orders($table,$page)
	{
		$data['data']=$this->model('account')->fetch_all($table,'','id desc',calc_page_limit($page, 15));
		$data['count']=$this->model('account')->count($table);
		return $data;
	}

    public function get_pay_obj()
    {
	   return new \Pay\Pay($this->config);
	}

  	public function add_finance_log($data)
  	{
  		return $this->model('account')->insert('finance_log',$data);
  	}

  	/*微信退款*/
    public function wxpay_refund($data)
    {
        $options=[
            'total_fee' => intval($data['amount'] * 100),       //订单金额     单位 转为分
            'refund_fee' => intval($data['amount'] * 100),       //退款金额 单位 转为分
            'transaction_id'=>$data['transaction_id'],               //微信订单号
            'out_trade_no'=>$data['out_trade_no'],        //商户订单号
            'out_refund_no'=>$data['out_refund_no'],        //商户退款单号
            'refund_desc'=>'活动退款',
        ];
        $pay = new \Pay\Pay($this->config);
        return $result = $pay->driver('wechat')->refund($options);
    }

	public function alicallbalk()
    {
		$pay = new \Pay\Pay($this->config);
		/*支付宝回调*/
		if ($pay->driver('alipay')->gateway()->verify($_POST)) {
			Log::DEBUG("call back， return alipay:" . json_encode($_POST));
			if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
				$order['updatetime']=strtotime($_POST['gmt_payment']);
				$order['status']=1;
				$order['remarks']='支付宝 充值成功';
				$order['trade_no']=$_POST['trade_no'];//支付宝订单号
				$out_trade_no=$_POST['out_trade_no'];//本系统订单号
				$this->updateHandle($_POST['trade_status'],$out_trade_no,$order);
		    }				
		}			
	}

	public function wxcallbalk()
    {
		$pay = new \Pay\Pay($this->config);
		/*微信回调*/
		if($verify = $pay->driver('wechat')->gateway('scan')->verify(file_get_contents('php://input'))){
			Log::DEBUG("call back， return wxpay:" . file_get_contents('php://input'));
			$order['updatetime']=strtotime($verify['time_end']);
			$order['status'] = 1;
			$order['remarks']='微信 充值成功';
			$order['trade_no'] = $verify['transaction_id'];//微信订单号
			$out_trade_no = $verify['out_trade_no'];//本系统订单号
			$code = $verify['return_code'];//SUCCESS 表示成功
			$this->updateHandle($code,$out_trade_no,$order);		
		}
	}

	public function updateHandle($code,$out_trade_no,$order)
    {
		// 对数据库进行操作
		if($code == 'TRADE_SUCCESS' || $code == 'SUCCESS')
		{
			$this->model('account')->begin_transaction();
	    	try{
	    		//根据订单号 查找订单信息
				$recharge = $this->model('account')->query_row("SELECT * FROM ".$this->model('account')->get_table('recharge')." WHERE hide=0 and out_trade_no='{$out_trade_no}' for update");
				if($recharge['status'] != 0){

					die('已处理');
					$this->roll_back();
				}
				
                //查找用户附属信息
                $user = $this->model('account')->query_row("SELECT id FROM ".$this->model('account')->get_table('users_attrib')." WHERE is_del=0 and uid={$recharge['uid']}");
                if(!$user){
                    die('找不到用户附属信息');
                    $this->roll_back();
                }

                //1悬赏2问题打赏3文章打赏4咨询
                if($recharge['pay_type'] == 1)
                {
                	$question_info = $this->model('question')->get_question_info_by_id($recharge['orderId']);
                    $remarks = '发布悬赏问题 #'.$recharge['orderId'];

                    if(!$question_info)
                    {
                        die('无该问题信息');
                        $this->roll_back();
                    }

                    $question_arr = array(
                        'reward_money' => $recharge['money'],
                        'is_reward' => 1,
                        'is_del' => 0
                    );

                    if(!$this->model('question')->update('question', $question_arr, 'question_id = '.$recharge['orderId']))
                    {
                        die('更新问题数据失败');
                        $this->roll_back();
                    }

                    $post_arr = array(
                        'is_del' => 0
                    );

                    if(!$this->model('question')->update('posts_index', $post_arr, 'post_type = "question" and post_id = '.$recharge['orderId']))
                    {
                        die('更新posts数据失败');
                        $this->roll_back();
                    }

                    $type = 1;
                }
                
                if($recharge['pay_type'] == 2)
                {
                	$answer_info = $this->model('answer')->get_answer_by_id($recharge['orderId']);

                    $remarks = '回答被打赏 #'.$recharge['orderId'];

                    if(!$answer_info)
                    {
                        die('无该回答信息');
                        $this->model('account')->roll_back();
                    }

                    $this->model('account')->query_all("UPDATE ".$this->model('account')->get_table('answer')." SET money=money+{$recharge['money']} where answer_id ={$recharge['orderId']}");

                    $type = 2;
                }

                if($recharge['pay_type'] == 3)
                {
                	$article_info = $this->model('article')->get_article_info_by_id($recharge['orderId']);

                    $remarks = '文章被打赏 #'.$recharge['orderId'];

                    if(!$article_info)
                    {
                        die('无该文章信息');
                        $this->model('account')->roll_back();
                    }

                    $this->model('account')->query_all("UPDATE ".$this->model('account')->get_table('article')." SET money=money+{$recharge['money']} where id ={$recharge['orderId']}");

                    $type = 3;
                }

                $order['remarks'] = $remarks . $order['remarks'];

                if(!$this->model('account')->update('recharge', $order, 'hide=0 and out_trade_no = "' .$out_trade_no.'"'))
                {
                    die('更新数据失败');
                    $this->model('account')->roll_back();
                }

                $this->model('account')->query_all("UPDATE ".$this->model('account')->get_table('user_account')." SET totalRecharge=totalRecharge+{$recharge['money']} where uid ={$recharge['uid']}");//个人

                //插入交易记录日志
                $logs = array(
                    'uid' => $recharge['uid'],
                    'recharge_id' => $recharge['id'],
                    'order_id' => $recharge['orderId'],
                    'type' => $type,
                    'money' => $recharge['money'],
                    'balance' => $this->model('account')->get_banlce($recharge['uid'])['balance'],
                    'pay_way' => $recharge['pay_way'],
                    'status' => 1,
                    'remarks' => $remarks,
                    'addtime' => time()
                );

                if(!$this->model('account')->insert('finance_log', $logs)){
                    die('插入交易记录日志失败');
                    $this->model('account')->roll_back();
                }

				$this->model('account')->commit();
				echo "success";die;	
				
			}catch (Exception $e){
				die($e->getMessage());
				$this->model('account')->roll_back();				
			}
		}else{
			$arr = array(
				'status' => 2,
				'updatetime' => time(),
				'remarks' => '失败'
			);
			$this->model('account')->update('recharge', $arr, 'hide=0 and out_trade_no = "' .$out_trade_no.'"');
		}
	}
}